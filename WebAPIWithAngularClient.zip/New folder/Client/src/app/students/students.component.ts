import { Component, OnInit } from '@angular/core';
import { StudentService } from './students.service';
import { IStudent } from './student';

@Component({
  selector: 'app-students',
  templateUrl: './students.component.html',
  styleUrls: ['./students.component.css']
})


export class StudentsComponent implements OnInit {
pageTitle: string = "Student List";
   filteredStudents: IStudent[] = [];
   students: IStudent[] = [];

   // implements OnInit {

     errorMessage = '';

//   filteredStudents: IStudent[] = [];
//   students: IStudent[] = [];

   constructor(private studentService: StudentService) {

   }
  ngOnInit(): void {
    this.studentService.getStudents().subscribe(
      students => {
        this.students = students;
        this.filteredStudents = this.students;
      },
      error => this.errorMessage = <any>error
    );
  }
}
