import { Injectable } from "@angular/core";
import {IStudent} from './student';
import { HttpClient, HttpErrorResponse }  from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';

@Injectable()
export class StudentService
{
    private studentUrl = 'http://localhost:55557/'
    constructor(private http: HttpClient) {}

    getStudents(): Observable<IStudent[]>{
    return this.http.get<IStudent[]>(this.studentUrl + "api/StudentModels")
    .pipe(tap(data => console.log('All' + JSON.stringify(data))),
    catchError(this.handleError)
    );
 }
 
 getStudent(id: number): Observable<IStudent | undefined> {
    return this.getStudents().pipe(
      map((students: IStudent[]) => students.find(p => p.studentId === id))
    );
  }

 private handleError(err: HttpErrorResponse) {
    // For now logging it to the console
    let errorMessage = '';
    if (err.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
    }
    console.error(errorMessage);
    return throwError(errorMessage);
  }



}