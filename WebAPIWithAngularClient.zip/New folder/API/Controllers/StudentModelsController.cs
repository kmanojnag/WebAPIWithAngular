﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using NagaKolukulaCodingExeAPI.Models;
using System.Web.Http.Cors;


namespace NagaKolukulaCodingExeAPI.Controllers
{
    [EnableCors(origins: "http://localhost", headers: "*", methods: "*")]

    public class StudentModelsController : ApiController
    {

        private StudentDBContext db = new StudentDBContext();

        // GET: api/StudentModels
        public IQueryable<StudentModel> GetStudentModels()
        {
            return db.StudentModels;
        }

        // GET: api/StudentModels/5
        [ResponseType(typeof(StudentModel))]
        public async Task<IHttpActionResult> GetStudentModel(int id)
        {
            StudentModel studentModel = await db.StudentModels.FindAsync(id);
            if (studentModel == null)
            {
                return NotFound();
            }

            return Ok(studentModel);
        }

        // PUT: api/StudentModels/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutStudentModel(int id, StudentModel studentModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != studentModel.ID)
            {
                return BadRequest();
            }

            db.Entry(studentModel).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StudentModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/StudentModels
        [ResponseType(typeof(StudentModel))]
        public async Task<IHttpActionResult> PostStudentModel(StudentModel studentModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.StudentModels.Add(studentModel);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = studentModel.ID }, studentModel);
        }

        // DELETE: api/StudentModels/5
        [ResponseType(typeof(StudentModel))]
        public async Task<IHttpActionResult> DeleteStudentModel(int id)
        {
            StudentModel studentModel = await db.StudentModels.FindAsync(id);
            if (studentModel == null)
            {
                return NotFound();
            }

            db.StudentModels.Remove(studentModel);
            await db.SaveChangesAsync();

            return Ok(studentModel);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool StudentModelExists(int id)
        {
            return db.StudentModels.Count(e => e.ID == id) > 0;
        }
    }
}