﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;

namespace NagaKolukulaCodingExeAPI.Controllers
{
    public class StudentController : ApiController
    {
        // GET: Student
        // this is a sample controller to test the solution
        public IHttpActionResult Get()
        {
            try
            {
                return Ok("Hello World");

            }
            catch (Exception ex)
            {
                return BadRequest("Error on API, contact support team");
            }
        }
    }
}