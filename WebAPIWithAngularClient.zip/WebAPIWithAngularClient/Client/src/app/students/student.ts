export interface IStudent {
    studentId: number;
    studentName: string;
    studentGrade: string;
    studentSchool: string;
}
  
  