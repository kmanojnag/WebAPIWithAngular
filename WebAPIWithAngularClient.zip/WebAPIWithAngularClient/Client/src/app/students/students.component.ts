import { Component, OnInit } from '@angular/core';
import { StudentService } from './students.service';
import { IStudent } from './student';
import { Router, ActivatedRoute } from '@angular/router';
import {CreateEditStudentComponent } from '../create-edit-student/create-edit-student.component';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-students',
  templateUrl: './students.component.html',
  styleUrls: ['./students.component.css']
})


export class StudentsComponent implements OnInit {
pageTitle: string = "Student List";
   filteredStudents: IStudent[] = [];
   students: IStudent[] = [];
     errorMessage = '';
     public selectedStudentId: number;

     constructor(private studentService: StudentService, 
      private _route: ActivatedRoute,
      private _router: Router) {    }
  

  ngOnInit(): void {
    this.studentService.getStudents().subscribe(
      (students) => {
        this.students = students;
        this.selectedStudentId = +this._route.snapshot.paramMap.get('studentId');        
        console.log((students));
      },
      error => this.errorMessage = <any>error
    );

  }

  public lclStudent: IStudent = {
    studentId: null,
    studentName: null,
    studentGrade: null,
    studentSchool: null
  };
   
  
  public show:boolean = false;
  public buttonName:any = 'Show';

  toggle() {
    this.show = !this.show;

    // CHANGE THE NAME OF THE BUTTON.
    if(this.show)  
      
    {
      this.buttonName = "Hide";
      
      // lclStudent  =  {
      //   studentId: null,
      //   studentName: null,
      //   studentGrade: null,
      //   studentSchool: null
      // };
    }
    else
      this.buttonName = "Show";
  }
   public _studentId: number;

public EditDetails(id: number)
{
  this.show = !this.show;

    this._studentId = +this._route.snapshot.paramMap.get('id');
    if (this._studentId > 0) {
      this.studentService.getStudent(this._studentId).subscribe(
        (student) => {
          this.lclStudent = student;
        }
      );

      this.studentService.getStudents().subscribe(
        (students) => {
          this.students = students;
          this.selectedStudentId = +this._route.snapshot.paramMap.get('studentId');        
          console.log((students));
        },
        error => this.errorMessage = <any>error
      );
    }
  }
  

  public SaveForm() {
    if (this._studentId === 0) {
      this.CreateStudent(this.lclStudent);
    } else {
      this.UpdateStudent(this._studentId, this.lclStudent);
    }
  }

  public get StudentForm(): NgForm {
      return this.StudentForm;
    }

  public CreateStudent(student: IStudent) {
    this.studentService.post(this.lclStudent).subscribe(
      (data) => {
        console.log(`On the Client: ${data}`);
        this.StudentForm.reset();
        this._router.navigate(['/Home']);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  public UpdateStudent(id: number, student: IStudent) {
    this.studentService.put(id, this.lclStudent).subscribe(
      () => {
        this.StudentForm.reset();
        this._router.navigate(['/Home']);
      },
      (error) => {
        console.log(error);
      }
    );
  }


  public DeleteStudent(id: number) {
    this.studentService.delete(id).subscribe(
      () => {
        this._router.navigate(['Home']);
      },
      (error) => {
        console.log(error);
      }
    );
  }
}
