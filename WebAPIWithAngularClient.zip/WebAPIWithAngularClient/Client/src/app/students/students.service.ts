import { Injectable } from "@angular/core";
import {IStudent} from './student';
import { HttpClient, HttpErrorResponse, HttpHeaders }  from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';

@Injectable()
export class StudentService
{
    private studentUrl = 'http://localhost:55557/'
    constructor(private http: HttpClient) {}

    getStudents(): Observable<IStudent[]>{
    
    //   return this.http.get<IStudent[]>(this.studentUrl + "api/StudentModels")
    // .pipe(tap(data => console.log('All' + JSON.stringify(data))),

    return this.http.get<IStudent[]>(this.studentUrl + "api/StudentModels")
      .pipe(catchError(this.handleError)
    );
 }
 
 public getStudent(id: number): Observable<IStudent | undefined> {
    return this.getStudents().pipe(
      map((students: IStudent[]) => students.find(p => p.studentId === id))
    );
  }
  
  public post(student: IStudent): Observable<IStudent> {
    return this.http.post<IStudent>(this.studentUrl + 'api/StudentModels/PostStudentModel', student, {
      headers: new HttpHeaders( {
        'content-type': 'application/json'
      })
    }).pipe(catchError(this.handleError));
  }

  public put(id: number, student: IStudent): Observable<void> {
    return this.http.put<void>(`${this.studentUrl + 'api/StudentModels/PutStudentModel?id='}/${id}`, student, {
      headers: new HttpHeaders( {
        'content-type': 'application/json'
      })
    }).pipe(catchError(this.handleError));
  }

  public delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.studentUrl + 'api/StudentModels/DeleteStudentModel?id='}${id}`, {
      headers: new HttpHeaders( {
        'content-type': 'application/json'
      })
    }).pipe(catchError(this.handleError));
  }

 private handleError(err: HttpErrorResponse) {
    // For now logging it to the console
    let errorMessage = '';
    if (err.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
    }
    console.error(errorMessage);
    return throwError(errorMessage);
  }
}