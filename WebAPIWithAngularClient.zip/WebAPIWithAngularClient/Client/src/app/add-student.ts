export class AddStudent {
    constructor (
        public id :number,
        public name : string,
        public grade : number,
        public school : string
    ) { }
}
