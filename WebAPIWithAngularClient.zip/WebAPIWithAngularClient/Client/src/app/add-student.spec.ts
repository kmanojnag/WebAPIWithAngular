import { AddStudent } from './add-student';

describe('AddStudent', () => {
  it('should create an instance', () => {
    expect(new AddStudent()).toBeTruthy();
  });
});
