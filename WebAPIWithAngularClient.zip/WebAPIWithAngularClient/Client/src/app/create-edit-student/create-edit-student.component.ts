import { Component, OnInit, ViewChild } from '@angular/core';
import { StudentService } from '../students/students.service';
import { IStudent } from '../students/student';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-create-edit-student',
  templateUrl: './create-edit-student.component.html',
  styleUrls: ['./create-edit-student.component.css']
})

export class CreateEditStudentComponent {

  name = new FormControl('');
}

// export class CreateEditStudentComponent implements OnInit {

//   @ViewChild('studentForm',{static: false}) public studentForm: NgForm;
//   public student: IStudent = {
//     studentId: null,
//     studentName: null,
//     studentGrade: null,
//     studentSchool: null
//   };

//   public _studentId: number;
//   constructor(private _studentService: StudentService,
//               private _route: ActivatedRoute,
//               private _router: Router) {
//   }

//   ngOnInit() {
//     this._studentId = +this._route.snapshot.paramMap.get('id');
//     if (this._studentId > 0) {
//       this._studentService.getStudent(this._studentId).subscribe(
//         (student) => {
//           this.student = student;
//         }
//       );
//     }
//   }

//   public SaveForm() {
//     if (this._studentId === 0) {
//       this.CreateStudent(this.student);
//     } else {
//       this.UpdateStudent(this._studentId, this.student);
//     }
//   }

//   public get StudentForm(): NgForm {
//       return this.studentForm;
//     }

//   public CreateStudent(student: IStudent) {
//     this._studentService.post(this.student).subscribe(
//       (data) => {
//         console.log(`On the Client: ${data}`);
//         this.studentForm.reset();
//         this._router.navigate(['/Home']);
//       },
//       (error) => {
//         console.log(error);
//       }
//     );
//   }

//   public UpdateStudent(id: number, student: IStudent) {
//     this._studentService.put(id, this.student).subscribe(
//       () => {
//         this.studentForm.reset();
//         this._router.navigate(['/Home']);
//       },
//       (error) => {
//         console.log(error);
//       }
//     );
//   }

// }
